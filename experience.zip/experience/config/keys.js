module.exports = {
  mongoURI: 'mongodb://bharatrosedb:ThisIsMyLife123@ds151626.mlab.com:51626/buyandsell',
  secretOrKey: 'secret'
};
