const express = require('express');
const router = express.Router();

const axios = require('axios');

// @route   GET api/weather/getweather
// @desc    Tests users route
// @access  Public
router.get('/test', (req, res) => res.json({ msg: 'Users Works' }));


router.get('/getweather/:lat/:lon', function(req, res) {

    // const 
    const {lat, lon} = req.params;

    // Check lat and ongi 
    if(lat === '' && lon === '') {

        return res.status(400).json({error:'Lat and lon is required'});
    }

    console.log(req.params);

    const url = `https://samples.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=b6907d289e10d714a6e88b30761fae22`;

    // Make a request for a user with a given ID
      axios.get(url)
        .then(function (response) {
          // handle success
          res.send(response);
        })
        .catch(function (error) {
          // handle error
          res.status(400).json(error);
        })
        .finally(function () {
          // always executed
        });


})


module.exports = router;
