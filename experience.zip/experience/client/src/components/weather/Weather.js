import React, { Component } from 'react';


import { connect } from 'react-redux';

import TextFieldGroup from '../common/TextFieldGroup';

class Weather extends Component {

  constructor(props) {
    super(props)
    this.state = {
    	details: {},
    	lon:'',
    	lat: ''
    }

    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this)
  }


  componentDidMount() {

  	// Get the request 
  	const {lon, lat } = this.state;

  	console.log(this.state);

    
  }
 onChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  }

  onSubmit() {

  }


  render() {
    return ( <form onSubmit={this.onSubmit}>
                <TextFieldGroup
                  placeholder="Lat"
                  name="lon"
                  type="text"
                  value={this.state.lon}
                  onChange={this.onChange}
                  
                />

                <TextFieldGroup
                  placeholder="Long"
                  name="lat"
                  type="text"
                  value={this.state.lat}
                  onChange={this.onChange}
                  
                />
                <input type="submit" className="btn btn-info btn-block mt-4" />
              </form>)
  }
}

Weather.propTypes = {
  
};

const mapStateToProps = state => ({
  
});

export default connect(mapStateToProps)( Weather );
