<?php
require('fetch-chat.php');
echo fetchUsers();

?>