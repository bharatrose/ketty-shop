Use the link in local host

localhost/sociallogin/vendor/hybridauth/hybridauth/hybridauth/view/